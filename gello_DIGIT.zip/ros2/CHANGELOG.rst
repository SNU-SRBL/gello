v0.2.0 (2025-07-16)
------------------
* feat: Multi-Arm support for Franka FR3 robots

v0.1.0 (2025-06-03)
------------------
* feat: franka_fr3_arm_controllers: joint impedance controller for Franka FR3 robots based on Gello input
* feat: franka_gello_state_publisher: reads input from a Gello and publishes it as `sensor_msgs/JointState` ROS 2 messages
* feat: franka_gripper_manager: control of Franka Hand and Robotiq 2F-85 grippers based on Gello input