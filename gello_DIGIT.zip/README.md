# GELLO with Force-Torque Sensor and DIGIT Tactile Sensors (`gello_ft`)

This folder contains a customized version of the [GELLO](https://wuphilipp.github.io/gello_site/) system developed by the SRBL lab, extended with 6-axis force-torque sensing and dual DIGIT tactile sensor capabilities. It integrates the following hardware:

* UR5e Robot Arm
* Robotis Gripper (RH-P12-RN)
* Robotous 6-axis Force-Torque Sensor
* Intel RealSense Camera
* GELLO Dynamixel-based Teleoperation Device
* **Dual DIGIT Tactile Sensors** (for parallel gripper fingers)

---

## 🔧 System Setup

### 1. Required Hardware Connections

* Connect 5V power to the **Dynamixel Power Hub Board** to activate the GELLO device after connecting the **U2D2** USB device to your desktop.
* Power and connect the **FT sensor** and **camera** to the PC.
* Connect the **UR5e robot** via Ethernet.
* Connect **DIGIT tactile sensors** via USB (typically appear as USB cameras).

---

### 2. Network Setup

Set the IP address of your **desktop** to match the UR robot’s subnet:

* **Robot IP**: `192.168.0.10`
* **Desktop IP example**: `192.168.0.101`

---

### 3. Identify Serial Devices

To verify that all USB devices (GELLO, gripper, FT sensor) are correctly recognized, run:
```bash
dmesg | grep tty
ls /dev/serial/by-id
```
The expected USB device assignments are:
| Device        | Port           | Notes                               |
| ------------- | -------------- | ----------------------------------- |
| **GELLO**     | `/dev/ttyUSB0` | U2D2 controller for Dynamixels      |
| **Gripper**   | `/dev/ttyUSB1` | Robotis RH-P12-RN gripper           |
| **FT Sensor** | `/dev/ttyUSB2` | Robotous 6-axis Force-Torque sensor |

### 4. Identify DIGIT Camera Indices

To identify which USB camera indices correspond to your DIGIT sensors:
```bash
cd ~/gello/gello_ft/
python gello/cameras/digit_camera.py
```
This will display available camera indices. Note which indices correspond to your left and right DIGIT sensors.

Expected output (example):

```
Available cameras: [0, 1, 2, 3]
```

Use this path in the `--port` argument below.

---

## ⚙️ Software Setup

### 1. Conda Environment & Python Path

Activate your conda environment:

```bash
conda activate <your-conda-env>
```

Add the current directory to the `PYTHONPATH`:

```bash
cd ~/gello/gello_ft/
export PYTHONPATH="$PYTHONPATH:$(pwd)"
```

---

### 2. Set Initial Robot Joint Position

Move the UR5e robot to the following known joint configuration before launching GELLO:

```
[0, -90, 90, -90, -90, 0]  (degrees)
```

Or in radians: `[0, -1.57, 1.57, -1.57, -1.57, 0]`

---

### 3. Run GELLO with FT Sensor

#### (1) Update Offset Before Use (Every Time)

```bash
python scripts/gello_get_offset.py \
    --start-joints 0 -1.57 1.57 -1.57 -1.57 0 \
    --joint-signs 1 1 -1 1 1 1 \
    --port /dev/serial/by-id/usb-FTDI_USB__-__Serial_Converter_FTA7NLK4-if00-port0
```

> ⚠️ After running, open `gello/agents/gello_agent.py` and update the printed offset values in the `PORT_CONFIG_MAP`.

---

#### (2) Camera Test (Optional)

Test RealSense cameras:
```bash
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 \
python experiments/launch_camera_nodes.py --hostname 127.0.0.1

python experiments/launch_camera_clients.py --hostname 127.0.0.1
```

Test DIGIT cameras:
```bash
python gello/cameras/digit_camera.py
```

---

#### (3) Launch GELLO System

**Terminal 1 - Camera Nodes (RealSense + DIGIT):**
```bash
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 \
python experiments/launch_camera_nodes.py --hostname 127.0.0.1 --digit_indices 2 3 --use_digit
```

**Terminal 2 - Robot Node:**
```bash
python experiments/launch_nodes.py --robot ur --robot_ip=192.168.0.10
```

**Terminal 3 - Main Control:**
```bash
python experiments/run_env.py --agent=gello --use_save_interface --sensor_ft --use_digit
```

---

## 🎯 **DIGIT Sensor Integration**

The DIGIT tactile sensors are integrated as camera nodes alongside the RealSense cameras. Key features:

- **Dual DIGIT Support**: Left and right gripper finger sensors
- **ZMQ Integration**: DIGIT data streams via same protocol as other cameras
- **Automatic Data Logging**: DIGIT frames included in saved datasets
- **Configurable Ports**: Specify camera indices via command line arguments

### DIGIT Configuration Options

- `--use_digit`: Enable DIGIT sensor integration (default: True)
- `--digit_indices`: Specify camera indices for DIGIT sensors (default: 2 3)

### Data Structure

When DIGIT sensors are enabled, the observation dictionary includes:
- `digit_left`: Left DIGIT camera frame (RGB)
- `digit_right`: Right DIGIT camera frame (RGB)
- Standard camera protocol compatibility (includes dummy depth channels)

---

## 📊 **Complete System Launch Sequence**

### Prerequisites
1. ✅ All hardware powered and connected
2. ✅ Network configured (Robot: 192.168.0.10, Desktop: 192.168.0.101)
3. ✅ Conda environment activated
4. ✅ PYTHONPATH set
5. ✅ Robot positioned at initial joints: `[0, -90, 90, -90, -90, 0]` (degrees)
6. ✅ GELLO offset calibrated

### Launch Commands (3 Terminals)

```bash
# Terminal 1: Launch all camera nodes
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 \
python experiments/launch_camera_nodes.py --hostname 127.0.0.1 --digit_indices 2 3 --use_digit

# Terminal 2: Launch robot node
python experiments/launch_nodes.py --robot ur --robot_ip=192.168.0.10

# Terminal 3: Run main teleoperation with all sensors
python experiments/run_env.py --agent=gello --use_save_interface --sensor_ft --use_digit
```

### Expected Ports
- **RealSense cameras**: 5000, 5001
- **DIGIT cameras**: 5002, 5003
- **Robot**: 6001

---

## 🔧 **Troubleshooting**

### DIGIT Camera Issues
```bash
# Check available cameras
python gello/cameras/digit_camera.py

# Test specific camera index
python -c "import cv2; cap=cv2.VideoCapture(2); print('Camera 2:', cap.isOpened()); cap.release()"
```

### Network Issues
```bash
# Check robot connectivity
ping 192.168.0.10

# Check your IP
hostname -I
```

### USB Device Issues
```bash
# Check USB devices
lsusb
dmesg | grep tty
```

