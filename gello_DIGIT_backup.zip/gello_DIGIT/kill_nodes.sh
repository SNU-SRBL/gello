pkill -9 -f launch_nodes.py
